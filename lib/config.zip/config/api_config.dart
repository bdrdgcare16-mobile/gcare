import 'package:flutter/foundation.dart';
import 'dart:io';

class ApiConfig {
  // 👇 CHANGE THIS to your system IP
  static const String _physicalDevice =
      'http://192.168.1.58:5001/serv-dev-f2557/us-central1/api';

  static const String _androidEmulator =
      'http://10.0.2.2:5001/serv-dev-f2557/us-central1/api';

  static const String _webLocal =
      'http://localhost:5001/serv-dev-f2557/us-central1/api';

  static const String _prod =
      'https://api-zmj7dqloiq-el.a.run.app/api';

  static String get baseUrl {
    if (kIsWeb) return _webLocal;

    try {
      if (Platform.isAndroid) {
        return _androidEmulator;
      }
    } catch (_) {}

    // 👇 for real mobile device
    return _physicalDevice;
  }

  static String get prodUrl => _prod;
}